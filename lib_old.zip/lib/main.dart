import 'package:flutter/material.dart';
import 'package:recetario_clase/screens/recipe_list_screen.dart';
void main() {
  runApp(const RecipeApp());
}

class RecipeApp extends StatelessWidget {
  const RecipeApp({super.key}); 

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        fontFamily: 'Lexend',
      ),
      home: RecipeListScreen(),
    );

  }
}
