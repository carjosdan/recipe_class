import 'package:flutter/material.dart';
import 'package:recetario_clase/styles/app_styles.dart';
import 'package:recetario_clase/widgets/recipe_card.dart';
import '../data/sample_recipes.dart';
import '../models/recipe.dart';

class RecipeListScreen extends StatefulWidget {
  const RecipeListScreen({super.key});

  @override
  State<RecipeListScreen> createState() => _RecipeListScreenState();
}

class _RecipeListScreenState extends State<RecipeListScreen> {

  final Set<Recipe> favorites = {};
  String query = '';
  TextEditingController searchController = TextEditingController(); 

  void toggleFavorite(Recipe recipe) {
    if (favorites.contains(recipe)){
      favorites.remove(recipe);
    } else {
      favorites.add(recipe);
    }
    setState(() {});
  }

  void clearSearch(){
    searchController.clear();
    query = '';
    setState(() {});
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    final filteredRecipes = sampleRecipes.
      where((element) => element.title.toLowerCase().contains(query.toLowerCase())).toList();


    return Scaffold(
      appBar: AppBar(
        title: Text('Recetario'),
        actions: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Stack(
              alignment: .center,
              children: [
                Icon(Icons.favorite, size: 40),
                Text(
                  '${favorites.length}',
                  style: AppStyles.sectionTitle
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                query = value;
                setState(() {});
              },
              decoration: InputDecoration(
                hintText: 'busca una receta',
                prefixIcon: Icon(Icons.search),
                suffixIcon: query.isEmpty ? null :
                IconButton(
                  onPressed: clearSearch,
                  icon: Icon(Icons.close),
                ),
              ),
            ),
          ),
          Expanded(
            child: filteredRecipes.isEmpty ?
            Center(child: Text('no se ha encontrado recetas.')):
            GridView.builder(
              // physics: ,
              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 250),
              itemCount: filteredRecipes.length, // Replace with the actual number of recipes
              itemBuilder: (context, index) {
                final recipe = filteredRecipes[index]; // Replace with the actual recipe data
                
                return RecipeCard(recipe: recipe, 
                isFavorite: favorites.isEmpty,
                onFavoritePressed: (){});
              },
            ),
          ),
        ],
      ),
    );
  }
}