import 'package:flutter/material.dart';
import 'package:recetario_clase/models/recipe.dart';

class RecipeCardFul extends StatefulWidget {
  const RecipeCardFul({super.key, required this.recipe});

  final Recipe recipe;

  @override
  State<RecipeCardFul> createState() => _RecipeCardFulState();
}

class _RecipeCardFulState extends State<RecipeCardFul> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          Text(widget.recipe.title),
          IconButton(
            onPressed: () {
              isFavorite = !isFavorite;
              setState(() {});
            }
            , 
            icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border ),
          )
        ],
      ),
    );
  }
}