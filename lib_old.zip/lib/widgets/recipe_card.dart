import 'package:recetario_clase/models/recipe.dart';
import 'package:flutter/material.dart';


class RecipeCard extends StatelessWidget {
  const RecipeCard({super.key, required this.recipe, required this.isFavorite, required this.onFavoritePressed, });

  final Recipe recipe;
  final bool isFavorite;
  final Function() onFavoritePressed;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: .antiAlias,
      child: Column(
        
        children: [
          Image.network(
            recipe.imageUrl,
            height: 150,
          ),
          Row(
            children: [
              IconButton(
                onPressed: onFavoritePressed, 
                icon: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}